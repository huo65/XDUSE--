public class MatrixChainOrder {
    public static void findOptimalParenthesis(int[] matrixDimensions) {
        int n = matrixDimensions.length - 1;
        int[][] minMultiplicationCost = new int[n + 1][n + 1];
        int[][] optimalSplitIndex = new int[n + 1][n + 1];
        
        for (int i = 0; i <= n; i++) {
            minMultiplicationCost[i][i] = 0;
            optimalSplitIndex[i][i] = 0;
        }
        /**
            外层循环控制连续矩阵的个数（chainLength）。
            中层循环控制起始矩阵的位置（start）。
            内层循环寻找中间分裂位置（splitIndex）来比较不同划分方案的代价。
         */
        for (int chainLength = 2; chainLength <= n; chainLength++) {
            for (int start = 1; start <= n - chainLength + 1; start++) {
                int end = start + chainLength - 1;
                minMultiplicationCost[start][end] = Integer.MAX_VALUE;
                
                for (int splitIndex = start; splitIndex <= end - 1; splitIndex++) {
                    int currentCost = minMultiplicationCost[start][splitIndex] 
                                    + minMultiplicationCost[splitIndex + 1][end] 
                                    + matrixDimensions[start - 1] * matrixDimensions[splitIndex] * matrixDimensions[end];
                    
                    if (currentCost < minMultiplicationCost[start][end]) {
                        minMultiplicationCost[start][end] = currentCost;
                        optimalSplitIndex[start][end] = splitIndex;
                    }
                }
            }
        }

        System.out.print("最小代价为：");
        System.out.println(minMultiplicationCost[1][n]);
    }



    public static void main(String[] args) {
        int[] a={3, 5, 2, 1, 10};
        int[] b={2, 7, 3, 6, 10};
        int[] c={10, 3, 15, 12, 7, 2};
        int[] d={7, 2, 4, 15, 20, 5};

        System.out.println("<3, 5, 2, 1,10>");
        findOptimalParenthesis(a);
        System.out.println("");
        System.out.println("<2, 7, 3, 6, 10>");
        findOptimalParenthesis(b);
        System.out.println("");
        System.out.println("<10, 3, 15, 12, 7, 2>");
        findOptimalParenthesis(c);
        System.out.println("");
        System.out.println("<7, 2, 4, 15, 20, 5>");
        findOptimalParenthesis(d);
        System.out.println("");


    }
}