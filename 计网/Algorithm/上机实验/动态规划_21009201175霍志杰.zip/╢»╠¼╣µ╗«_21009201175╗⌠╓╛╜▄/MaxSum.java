import java.util.Arrays;

public class MaxSum {
    public int maxSum(int[] nums) {
        int ans = nums[0];
        int sum = 0;
        for(int number: nums) {
            if(sum > 0) {
                sum += number;
            } else {
                sum = number;
            }
            ans = Math.max(ans, sum);
        }
        return ans;
    }
    public static void main(String[] args) {
        
        int[] arr = new int[]{-2,11,-4,13,-5,-2};
        System.out.println("序列为："+ Arrays.toString(arr));
        System.out.println("最大字序和为："+(new MaxSum()).maxSum(arr));
    }
}
