import java.util.Arrays;
/**
 * 设计和实现一个优先队列
 */
public class A1_2{

    private final Integer[] queue;
    private int N;

    public A1_2(int capacity) {
        queue = new Integer[capacity+1];
    }


    public void Insert(int t) {
        queue[++N] = t;
        swim(N);
        System.out.println("优先队列插入"+t+"后为"+ toString(queue, N));
    }

    public int Extract_MAX() {
        int max = queue[1];
        System.out.println("已取出优先队列最大值"+max);
        swap(1, N);
        queue[N] = null;
        N = N - 1;
        // 下沉
        sink(1);
        return max;
    }

    public int Maximum(){
        System.out.println("此时优先队列最大值为："+queue[1]);
        return queue[1];
    }


    public int size() {
        return N;
    }
// 下沉函数：sink 将父节点和较大的子节点比较，如果子节点大则交换位置并继续比较，否则结束比较
    public void sink(int k) {
       while(2*k <= N){
        // 找较大子节点
           int j = 2 * k;
           if(j<N && queue[j]<queue[j+1]){
               j++;
           }
        //    进行比较
           if (queue[k] >= queue[j]){
               break;
           }
           else
               swap(k,j);
           k = j;
       }
    }
// 上浮函数：swim是子节点与父节点比较，如果子节点大则交换位置并继续比较
    public void swim(int k) {
        while (k>1 && queue[k]>queue[k/2]){
            swap(k,k/2);
            k = k / 2;
        }
    }

    public void swap(int i, int j) {
        int temp = queue[i];
        queue[i] = queue[j];
        queue[j] = temp;
    }

     public static <T> String toString(T[] array, int size) {  
        if (array == null) {  
            return "null";  
        }  
          
        StringBuilder sb = new StringBuilder();  
        sb.append("[");  
        for (int i = 1; i <= size; i++) {  
            sb.append(array[i]);  
            if (i < array.length - 1) {  
                sb.append(", ");  
            }  
        }  
        sb.append("]");  
        return sb.toString();  
    }  



    public static void main(String[] args) {
        A1_2 queue = new A1_2(5);
        int[] nums = new int[]{9,5,1,8,10};
        for(int i=0; i<nums.length; i++){
            queue.Insert(nums[i]);
            queue.Maximum();
        }
        queue.Maximum();
        for (int i=0; i<nums.length; i++){
            queue.Extract_MAX();
        }
    }
}





