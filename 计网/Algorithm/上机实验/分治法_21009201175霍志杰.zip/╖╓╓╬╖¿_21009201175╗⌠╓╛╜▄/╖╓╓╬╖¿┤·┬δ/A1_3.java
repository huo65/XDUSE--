import java.util.Arrays;
import java.util.Random;
/**
 * 实现快排并且分析元素全部相同的数组比较的次数和最坏/好情况下的比
较次数。
 */
public class A1_3 {
    private static Random random = new Random(System.currentTimeMillis());
    public static int cnt = 0;
    /* 元素交换 */
    void swap(int[] nums, int i, int j) {
        int tmp = nums[i];
        nums[i] = nums[j];
        nums[j] = tmp;
    }

//     /* 哨兵划分 */
//     int partition(int[] nums, int left, int right) {
//         // 以 nums[left] 为基准数
//         int i = left, j = right;
//         while (i < j) {
//             while (i < j && nums[j] >= nums[left])
//                 j--;          // 从右向左找首个小于基准数的元素
//             while (i < j && nums[i] <= nums[left])
//                 i++;          // 从左向右找首个大于基准数的元素

//             cnt += 2;
//             swap(nums, i, j); // 交换这两个元素
//         }
//         swap(nums, i, left);  // 将基准数交换至两子数组的分界线
//         return i;             // 返回基准数的索引
//     }
//     /* 快速排序 */
// void quickSort(int[] nums, int left, int right) {
//     // 子数组长度为 1 时终止递归
//     if (left >= right)
//         return;
//     // 哨兵划分
//     int pivot = partition(nums, left, right);
//     // 递归左子数组、右子数组
//     quickSort(nums, left, pivot - 1);
//     quickSort(nums, pivot + 1, right);
// }
public void quickSort(int[] nums, int left, int right){
        if(left>right)    return;
        if(right>left){
            int randomindex = random.nextInt(right-left)+left+1;
            swap(nums,left,randomindex);
        }
        int pivot = nums[left];
        int j = left;

        for(int i=left+1; i<=right; i++){
            if(nums[i]<pivot){
                j++;
                swap(nums,i,j);
            }
            cnt++;
        }
        swap(nums,left,j);

        quickSort(nums,left,j-1);
        quickSort(nums,j+1,right);
    }
    public static void main(String[] args) {
        int[] nums1 = new int[]{1,1,1,1,1,1,1,1,1};
        int[] nums2 = new int[]{9,8,7,6,5,4,3,2,1};
        int[] nums3 = new int[]{1,2,3,4,5,6,7,8,9};
        int[] nums4 = new int[]{5,1,9,3,7,4,8,6,2};
        int[] nums5 = new int[]{1,11,2,31,0,100,19,91,30};

        System.out.println("排序前数组为："+Arrays.toString(nums1));
        (new A1_3()).quickSort(nums1,0, nums1.length-1);
        System.out.println("排序后数组为："+Arrays.toString(nums1));
        System.out.println("比较次数为： "+cnt);

        cnt = 0;
        System.out.println("排序前数组为："+Arrays.toString(nums2));
        (new A1_3()).quickSort(nums2,0, nums2.length-1);
        System.out.println("排序后数组为："+Arrays.toString(nums2));
        System.out.println("比较次数为： "+cnt);

        cnt = 0;
        System.out.println("排序前数组为："+Arrays.toString(nums3));
        (new A1_3()).quickSort(nums3,0, nums3.length-1);
        System.out.println("排序后数组为："+Arrays.toString(nums3));
        System.out.println("比较次数为： "+cnt);

        cnt = 0;
        System.out.println("排序前数组为："+Arrays.toString(nums4));
        (new A1_3()).quickSort(nums4,0, nums4.length-1);
        System.out.println("排序后数组为："+Arrays.toString(nums4));
        System.out.println("比较次数为： "+cnt);

        cnt = 0;
        System.out.println("排序前数组为："+Arrays.toString(nums5));
        (new A1_3()).quickSort(nums4,0, nums4.length-1);
        System.out.println("排序后数组为："+Arrays.toString(nums5));
        System.out.println("比较次数为： "+cnt);
    }

}
