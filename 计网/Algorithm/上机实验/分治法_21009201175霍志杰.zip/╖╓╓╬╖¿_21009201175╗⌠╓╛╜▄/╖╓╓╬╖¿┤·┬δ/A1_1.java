import java.util.Arrays;
/**
 * 实现一个能确定整数数组中是否存在两元素之和为整数 x 的算法，要求
时间复杂度为 0(nlogn)
 */
public class A1_1 {
    public boolean twoSum(int[] S, int x){
        System.out.println("数组排序前："+Arrays.toString(S));
        merge_sort(S,0,S.length-1);
        System.out.println("数组归并排序后："+Arrays.toString(S));
        for(int i=0; i<S.length-1; i++){
            if(S[i] < x){
                if(binary_search(S,x - S[i],i,S.length-1)){
                    System.out.println("数组S中存在两元素之和为"+x);
                    return true;
                }
            }
        }
        System.out.println("数组S中不存在两元素之和为"+x);
        return false;
    }

    public void merge_sort(int[] nums, int left, int right){
        if(left >= right){
            return;
        }
        int mid = (left + right) / 2;
        merge_sort(nums, left, mid);
        merge_sort(nums, mid + 1, right);

        merge(nums, left, mid, right);
    }

    public void merge(int[] nums, int left, int mid, int right){
// 左子数组区间为 [left, mid], 右子数组区间为 [mid+1, right]
// 创建一个临时数组 tmp ，用于存放合并后的结果
        int[] tmp = new int[right - left + 1];
        int i = left, j = mid + 1, k = 0;
        while(i <= mid && j <= right){
            if(nums[i] <= nums[j]){
                tmp[k++] = nums [i++];
            }else{
                tmp[k++] = nums[j++];
            }
        }
        while(i <= mid){
            tmp[k++] = nums[i++];
        }
        while(j <= right){
            tmp[k++] = nums[j++];
        }

        for(k = 0; k < tmp.length; k++){
            nums[left + k] = tmp[k];
        }

    }

    public boolean binary_search(int[] S, int target, int left, int right){
        while(left <= right){
            int mid = (left + right)  / 2;
            if(S[mid] == target){
                return true;
            }else if(S[mid] > target) {
                right = mid - 1;
            }else {
                left = mid + 1;
            }
        }

        return false;
    }

    public static void main(String[] args) {
        int[] nums1 = new int[]{9,8,7,6,5,4,3,2,1};
        int x1 = 8;
        (new A1_1()).twoSum(nums1,x1);
        int[] nums2 = new int[]{9,8,7,6,5,4,3,2,2};
        int x2 = 100;
        (new A1_1()).twoSum(nums2,x2);
    }
}
