public class A3_4 {
    private final static int N=10000;

    // Floyd算法
    public static void Floyd(int[][] matrix) {
        int n = matrix.length;
        // 同样使用了松弛的思想，与第三题相比要将dist 矩阵扩展为 2 维矩阵
        int[][] dist = new int[n][n];
        for (int i = 0; i < n; i++) {
            System.arraycopy(matrix[i], 0, dist[i], 0, n);
        }
        // 增加一重循环对每个点进行遍历
        for (int k = 0; k < n; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    
                    if (dist[i][k] + dist[k][j] < dist[i][j]) {
                        if(dist[i][k] == N || dist[k][j] == N){
                            continue;
                        }
                        dist[i][j] = dist[i][k] + dist[k][j];
                    }
                }
            }
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if(dist[i][j] == N){
                    System.out.println("源结点到" + i + "到" + j + "无最短距离");
                }else{
                System.out.println("源结点到" + i + "到" + j + "的最短距离为：" + dist[i][j]);
                }
            }
        }
    }

    public static void main(String[] args) {
        int[][] matrix = {
                {0, -1, 3, N, N},
                {N, 0, 3, 2, 2},
                {N, N, 0, N, N},
                {N, 1, 5, 0, N},
                {N, N, N, -3, 0}
        };

        Floyd(matrix);
    }
}
