import java.util.Arrays;
/**
如果时间长的进程优先运行则所有进程都需等待更长的时间才能运行
 */
public class A3_2 {
    public static void Scheudle(int[] s) {
        //  从小到大排序
        Arrays.sort(s);

        int c=0;
        int sum = 0;
        for(int i=0;i<s.length;i++) {
            System.out.print(s[i]+" ");
            c       = c + s[i];
            sum     = c + sum;
        }
        double avg=((double)sum)/((double)s.length);
        System.out.println("最小平均完成时间为："+avg);

    }
/**
 * 短作业优先，排序，然后贪心
 * @param args
 */
    public static void main(String[] args) {
        int[] arrays= {15,8,3,10};
        System.out.print("进程运行顺序为：");
        Scheudle(arrays);
    }

}
